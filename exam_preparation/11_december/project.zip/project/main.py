a = []
print(a[-1])
