# from project.library import Library
# from project.user import User
# from registration import Registration
#
#
# user = User(12, 'Peter')
# library = Library()
# registration = Registration()
# registration.add_user(user, library)
#
# registration.remove_user(user, library)
# print(library.user_records)