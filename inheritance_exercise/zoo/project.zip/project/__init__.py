# from animal import Animal
# from bear import Bear
# from gorilla import Gorilla
# from lizard import Lizard
# from mammal import Mammal
# from reptile import Reptile
# from snake import Snake
#
